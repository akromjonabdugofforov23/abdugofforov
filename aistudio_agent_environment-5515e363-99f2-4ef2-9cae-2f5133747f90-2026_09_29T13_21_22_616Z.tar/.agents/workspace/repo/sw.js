// ===== Abdugofforov PWA Service Worker =====
// App-shell keshlash: oflayn ishlash va tezroq yuklash uchun.
// CACHE versiyasini bump qildik (v2) — yangi dark dizayn keshda eski versiya
// bilan qorishib qolmasligi uchun
const CACHE = 'abdu-cache-v7';
const SHELL = [
    '/',
    '/index.html',
    '/style.css',
    '/style.min.css',
    '/animations.css',
    '/css/horror.css',
    '/app.js',
    '/i18n.js',
    '/storage.js',
    '/auth.js',
    '/data-flashcards.js',
    '/data-tests.js',
    '/scripts/flashcards.js',
    '/scripts/tests.js',
    '/scripts/horror-data.js',
    '/scripts/horror-logic.js',
    '/scripts/gamification.js',
    '/scripts/quote-widget.js',
    '/scripts/pro-3d-background.js',
    '/scripts/bg-worker.js',
    '/manifest.webmanifest',
    '/icon.svg',
    '/og-image.svg'
];

self.addEventListener('install', (event) => {
    event.waitUntil(
        caches.open(CACHE).then((c) => c.addAll(SHELL)).catch(() => {})
    );
    self.skipWaiting();
});

self.addEventListener('activate', (event) => {
    event.waitUntil(
        caches.keys().then((keys) =>
            Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))
        ).then(() => self.clients.claim())
    );
});

self.addEventListener('fetch', (event) => {
    const req = event.request;
    if (req.method !== 'GET') return;

    const url = new URL(req.url);
    // Faqat shu domen; YouTube/Unsplash/API ni keshlamaymiz
    if (url.origin !== self.location.origin) return;

    // Admin, maxfiy servislar va API funksiyalarini mutlaqo keshlamaymiz
    const noCachePaths = ['/kay', '/kay.html', '/cv', '/cv.html', '/tools', '/tools.html', '/deutsch', '/deutsch.html'];
    if (url.pathname.startsWith('/functions') || url.pathname.startsWith('/admin') || noCachePaths.includes(url.pathname)) return;

    // Navigatsiya (HTML) — tarmoq birinchi, keyin kesh (faqat asosiy sahifa oflayn ishlashi uchun)
    if (req.mode === 'navigate') {
        event.respondWith(
            fetch(req).then((res) => {
                if (url.pathname === '/' || url.pathname === '/index.html') {
                    const copy = res.clone();
                    caches.open(CACHE).then((c) => c.put('/index.html', copy)).catch(() => {});
                }
                return res;
            }).catch(() => {
                if (url.pathname === '/' || url.pathname === '/index.html') {
                    return caches.match('/index.html').then((r) => r || caches.match('/'));
                }
                return new Response('Oflayn rejim', { status: 503, headers: { 'Content-Type': 'text/plain; charset=utf-8' } });
            })
        );
        return;
    }

    // Yangi hikmatlar va widget skripti har doim tarmoqdan eng so'nggi holatda olinsin (Network-first)
    if (url.pathname.endsWith('quotes.json') || url.pathname.includes('quote-widget')) {
        event.respondWith(
            fetch(req).then((res) => {
                if (res && res.status === 200) {
                    const copy = res.clone();
                    caches.open(CACHE).then((c) => c.put(req, copy)).catch(() => {});
                }
                return res;
            }).catch(() => caches.match(req))
        );
        return;
    }

    // Boshqa statik resurslar — Stale-While-Revalidate (0ms tezkor ochilish + fonda yangilanish)
    event.respondWith(
        caches.match(req).then((cached) => {
            const networkFetch = fetch(req).then((res) => {
                if (res && res.status === 200) {
                    const copy = res.clone();
                    caches.open(CACHE).then((c) => c.put(req, copy)).catch(() => {});
                }
                return res;
            }).catch(() => cached);

            return cached || networkFetch;
        })
    );
});
